Hola me llamo Alex
Estoy empezando el curso de Python
Espero aprender mucho
